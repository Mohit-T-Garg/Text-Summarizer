# Python Framework for Extractive Text Summarization
Implementation based on the paper "Centroid-based Text Summarization through Compositionality of Word Embeddings" accepted at MultiLing Workshop at EACL 2017. http://www.aclweb.org/anthology/W17-1003

##This file is part of Text Summarizer project under Machine Learning Intern at Suvidha Foundations (June 2022) that my team prepared .

Name -- > Mohit Garg

## the other parts of this project include web development and multi - document text summarizer are currently going on and I have no license to share them on official platform.
